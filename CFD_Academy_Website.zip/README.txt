CFD ACADEMY — PUBLISHING GUIDE

This is a static educational website. It does not connect to a broker or provide live market data.

PUBLISH WITH GITHUB PAGES (FREE)
1. Sign in to https://github.com
2. Click the + icon (top-right) and choose New repository.
3. Repository name: cfd-academy
4. Choose Public. Tick "Add a README file" if shown, then Create repository.
5. On the repository page, choose Add file > Upload files.
6. Upload index.html from this folder. Commit changes.
7. Open Settings > Pages.
8. Under Build and deployment, choose Deploy from a branch.
9. Select branch main and folder /(root), then Save.
10. Wait a few minutes. GitHub will show your public website address in Settings > Pages.

The site will be public and accessible to anyone with the link (and potentially discoverable). GitHub Pages on a public repository is suitable for this no-cost public course, not private/password-protected content.

To update the site later, upload a replacement index.html and commit the change.

IMPORTANT
The course is educational only. It is not investment advice, does not recommend trades and does not provide live quotes. Check current regulatory information and the provider's own terms before making any financial decision.
